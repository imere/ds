# 颜色值写法：hex / rgba / 通道变量 / color-mix

## 判断依据

只有**一个问题**：

> 这个颜色下面会露出什么？

- **答得出来**（实色，下面永远是你自己）→ **hex**
- **答不出来**（要压在任意底色上）→ 必须带 alpha

## 四种写法

### 1. hex —— 实色

```js
bg: '#ffffff'
fg: '#0f172a'
brand: '#4f46e5'
swatch: '#4f46e5'
```

用在：表面、文字、描边、品牌实色、色卡预览。

理由：**可被外部工具读取**。Figma 导入、设计稿比对、导出 JSON、人眼审阅——`#4f46e5` 一眼能念出来，`rgb(79 70 229)` 不能。

### 2. `rgba()` 固定通道 —— 半透明叠层

```js
bgHover:   'rgba(15, 23, 42, 0.045)'
bgActive:  'rgba(15, 23, 42, 0.085)'
bgDisabled:'rgba(15, 23, 42, 0.04)'
overlay:   'rgba(15, 23, 42, 0.46)'
```

用在：hover / active / disabled 态、遮罩、任何要压在不确定底色上的东西。

理由：hover 可能落在 `bg`、`bgSubtle` 或一张卡片上。用 hex 就得为每种组合预烘焙一个色，那是组合爆炸。

深色主题下 hover / active 方向相反，用白色半透明：

```js
bgHover:  'rgba(255, 255, 255, 0.065)'
bgActive: 'rgba(255, 255, 255, 0.11)'
```

### 3. 通道变量 + `rgb(var(--x) / α)` —— 半透明且颜色本身要变

当颜色值不固定（跟着强调色或主题变），且需要多个透明度时：

```js
// 强调色工厂：rgb 是裸通道 '79 70 229'
const brand = (main, hover, active, focus, rgb) => ({
  brand:        main,
  brandHover:   hover,
  brandActive:  active,
  brandSubtle:  `rgba(${rgb}, 0.12)`,
  brandBorder:  `rgba(${rgb}, 0.32)`,
  brandFg:      hover,
  focus:        main,
})

accents.indigo = { label: '靛蓝', swatch: '#4f46e5',
  tokens: brand('#4f46e5', '#4338ca', '#3730a3', '#6366f1', '79 70 229') }
```

```css
/* 阴影：通道本身是变量，明暗主题各给一份 */
--ds-shadow-color: 15 23 42;              /* light */
box-shadow: 0 1px 2px 0 rgb(var(--ds-shadow-color) / 0.06);

--ds-shadow-color: 0 0 0;                 /* dark */
box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.5);
```

**必须用现代空格语法 `rgb(R G B / α)`，不能用逗号语法 `rgba(R, G, B, α)`** —— 只有空格语法能把 `var()` 直接塞进去，逗号语法里混 `var()` 会解析失败。

### 4. `color-mix()` —— 从已有令牌派生

```css
/* 顶栏毛玻璃：从 --ds-color-bg 派生 82% 不透明的版本 */
background: color-mix(in srgb, var(--ds-color-bg) 82%, transparent);
background: var(--ds-color-bg);   /* 老浏览器 fallback，必须在前一行 */
```

好处是不用把 `--ds-color-bg` 拆成三个通道。代价是兼容性（Chrome 111+ / Safari 16.2+），**必须留 fallback**：先写 fallback 再写 `color-mix`，靠层叠覆盖。

## 速查表

| 场景 | 写法 | 例子 |
|---|---|---|
| 实色表面 / 文字 / 描边 / 色卡 | `hex` | `bg: '#ffffff'` |
| 半透明叠层（hover / active / overlay） | `rgba()` 固定通道 | `rgba(15, 23, 42, 0.045)` |
| 半透明且需随主题 / 强调色换色 | 通道变量 + `rgb(var(--x) / α)` | `rgba(${rgb}, 0.12)` |
| 从已有令牌派生半透明 | `color-mix()` | `color-mix(in srgb, var(--x) 82%, transparent)` |

## hsl 什么时候用

本项目不用，因为语义色是**手工挑选**的（要过对比度、要好看），不是算出来的。`#16a34a` 比 `hsl(142 71% 45%)` 可读得多。

hsl 的适用场景只有一个：**需要程序化生成色阶**。比如给一个基础色自动派生 50~900 九档。如果未来要做"自动色阶生成器"，再引入。

## 深色主题的 Subtle 为什么不能用浅 hex

深色主题下根本不存在"浅色实底"这个概念。要在 `#0b0f17` 上做出品牌色的一层淡底，只能是"半透明的亮色叠上去"：

```js
// dark
brandSubtle: 'rgba(99, 102, 241, 0.16)'
```

反过来，浅色主题下 `#eef2ff` 虽然能跑，但它是**不透明**的，叠在 `bgSubtle`（`#f7f9fc`）上会盖掉底纹，而深色侧是融合的——同一 Token 两种行为。**统一用 rgba，两个主题行为才一致。**
