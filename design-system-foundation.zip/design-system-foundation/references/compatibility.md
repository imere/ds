# 浏览器兼容：分级策略与工具链

## 第 0 步：先定 Tier，再谈方案

兼容性不是"加个 polyfill"就完事——**这套方案的地基（CSS 自定义属性）本身就有支持下限**。动手前必须先明确目标浏览器，否则会做出返工级的技术选型。

| Tier | 目标 | 地基 | 换肤能力 |
|---|---|---|---|
| **A 现代** | 近两年 evergreen（Chrome / Edge / Firefox / Safari） | CSS 变量原生可用 | 运行时切换，零重渲染 |
| **B 保守** | iOS 13 / Safari 13 及以上 | CSS 变量可用 | 运行时切换，但需避开若干新 CSS 属性 |
| **C IE11** | IE11、Opera Mini | **CSS 变量不可用** | 运行时换肤需整体降级 |

> **Tier C 是架构级决策，不是补丁级。** 若必须支持 IE11，整套"CSS 变量注入 `<html>`"方案要换成"多套静态 CSS + class 切换"，Token 的下发方式、防闪烁脚本、主题注册机制全部要重写。这时候应优先争取把 IE 排除出目标。

## 风险清单（按严重度）

### 致命 —— 决定方案存亡

| 特性 | 支持起点 | 影响 |
|---|---|---|
| CSS 自定义属性 | IE ❌ / Edge 15+ / Safari 10.1+ / Chrome 49+ | IE 下**整个 Token 体系失效**，所有 `var(--ds-*)` 求值失败 |
| `Proxy` | IE ❌ | Vue 3 在 IE 上无法运行（Vue 2 用 `defineProperty`，可到 IE9） |

### 高 —— 会导致明显错乱

| 特性 | 支持起点 | 影响 |
|---|---|---|
| `color-mix()` | Chrome 111+ / Safari 16.2+ / Firefox 113+ | 毛玻璃、派生半透明失效，回到 fallback 值 |
| flexbox `gap` | Safari 14.1+ | 布局间距全部归零，卡片挤在一起 |
| `aspect-ratio` | Safari 15+ | 固定比例的头像 / 缩略图塌陷 |
| `inset` | Safari 14.1+ | 绝对定位失效 |
| `:focus-visible` | Safari 15.4+ | 键盘焦点样式退化（用 `:focus` 兜底） |
| `Object.assign` / `Array.includes` / `Object.entries` | IE ❌ | JS 运行时报错，需 core-js |

### 中 —— 有降级路径

| 特性 | 支持起点 | 降级 |
|---|---|---|
| `rgb(R G B / α)` 空格语法 | Chrome 65+ / Safari 12.1+ | 本就依赖 CSS 变量，IE 场景一起处理 |
| `matchMedia` | IE10+ | IE10/11 只有 `addListener`，需分支 |
| `prefers-color-scheme` | Safari 12.1+ | 不支持就不跟随系统 |
| `localStorage` | IE8+ | 隐私模式抛异常，必须 try/catch |

### 低 —— 本项目不依赖

CSS 嵌套、`:has()`、容器查询、`@layer` —— 都不要在组件样式里用。

## 渐进增强：两条铁律

**1. `var()` 的第二个参数就是 fallback，老浏览器会用它：**

```css
.ds-card {
  color: var(--ds-color-fg, #0f172a);
}
```

**2. 不支持变量时，靠层叠覆盖提供静态值：**

```css
.ds-card {
  background: #ffffff;                        /* 老浏览器读这行 */
  background: var(--ds-color-bg-elevated);    /* 支持变量的覆盖掉上面 */
}
```

两条铁律的代价是每个用到变量的地方写两遍。**只在 Tier C 需要**，Tier A/B 不要为此污染代码。

## 工具链推荐

### 单一事实来源：browserslist

所有工具（Babel / PostCSS / ESLint / Vite）都读它，不要各配各的：

```jsonc
// package.json
"browserslist": [
  "> 0.5%",
  "last 2 versions",
  "not dead",
  "not ie 11"          // ← Tier A/B 明确排除
]
```

或独立 `.browserslistrc`。随时用 `npx browserslist` 查看实际命中的浏览器列表。

### Tier A —— 最小集

```js
// vite.config.js
build: { target: 'esnext' }
```

只需为 `color-mix()` 留 fallback，其余无需处理。

### Tier B —— 加前缀与语法降级

```bash
npm i -D autoprefixer postcss
```

```js
// postcss.config.js
module.exports = { plugins: { autoprefixer: {} } }
```

autoprefixer 只管**前缀**，`aspect-ratio` / flex `gap` / `inset` 这类**属性本身不存在**的问题它解决不了，需手工降级：

```css
/* flex gap 的降级：用 margin 模拟，加 @supports 保护 */
.ds-stack > * + * { margin-top: var(--ds-space-3); }
@supports (gap: 1px) {
  .ds-stack { display: flex; gap: var(--ds-space-3); }
  .ds-stack > * + * { margin-top: 0; }
}
```

### Tier C —— 完整转译

```bash
npm i -D @vitejs/plugin-legacy terser
```

```js
// vite.config.js
import legacy from '@vitejs/plugin-legacy'

plugins: [
  legacy({
    targets: ['ie >= 11'],
    additionalLegacyPolyfills: ['regenerator-runtime/runtime'],
  }),
],
build: { target: 'es2015' }
```

`@vitejs/plugin-legacy` 会自动产出 legacy chunk、注入 core-js polyfill、加 `nomodule` 属性——现代浏览器仍走现代包，不牺牲性能。

底层是 `@babel/preset-env` + `core-js`，非 Vite 项目直接配这两个即可：

```js
// babel.config.js
presets: [['@babel/preset-env', { useBuiltIns: 'usage', corejs: 3 }]]
```

### Tier C 的换肤降级（两条路）

**方案 1：多套静态 CSS + class 切换**

构建时为主题数生成 N 份 CSS，切主题时换 `<link>` 或切 `<html class>`：

```css
.ds-card { background: #ffffff; }
[data-ds-theme='dark'] .ds-card { background: #0b0f17; }
```

- 优点：纯 CSS，IE 完美支持，首屏无闪烁
- 缺点：主题数 × 选择器数 = CSS 体积线性膨胀；新增主题要重新构建，**失去运行时注册能力**

**方案 2：`css-vars-ponyfill`**

```js
import cssVars from 'css-vars-ponyfill'
cssVars({ watch: true, variables: resolveCssVars() })   // 切主题后重新调用
```

- 优点：保留运行时换肤与运行时注册
- 缺点：每次切换要把全量 CSS 重新求值并注入 `<style>`，大项目有**几十到几百毫秒卡顿**；不支持 `@media` 内的动态变量等高级用法

经验：**主题数 ≤ 3 且固定**用方案 1，**主题数多或需后台下发**用方案 2。

### 能力检测

不要猜，直接问浏览器：

```js
const supportsCssVars =
  typeof window !== 'undefined' &&
  window.CSS && CSS.supports && CSS.supports('--a', '0')
```

`supportsCssVars === false` 时走 Tier C 分支（加载静态 CSS 或启用 ponyfill）。

## 验证

**jsdom 测不出兼容问题** —— 它不真正渲染 CSS，也不实现 `CSS.supports`。验证必须落真实浏览器：

```bash
npx playwright install
```

用 Playwright 起多个引擎（chromium / webkit / firefox）跑同一套视觉快照，重点看：

- 深色主题下阴影是否可见
- flex `gap` 是否生效（Tier B）
- 键盘焦点环是否出现（`:focus-visible` 降级）
- 首个 paint 是否闪白（防闪烁脚本）

## 组件库与框架的基线

选型时一并考虑，别让框架成为短板：

| 库 / 框架 | 基线 | 备注 |
|---|---|---|
| Vue 2 | IE9+ | 用 `Object.defineProperty` 实现响应式 |
| Vue 3 | **不支持 IE** | `Proxy` 无法 polyfill |
| Element UI 2 | IE10+ | 官方声明 |
| Element Plus | 不支持 IE | Vue 3 生态 |
| Ant Design 4 | IE11+（需 polyfill） | 5.x 起不再支持 |

## 落地检查清单

- [ ] `package.json` 或 `.browserslistrc` 里写死了明确的目标（不含模糊的 "defaults"）
- [ ] `npx browserslist` 输出的列表与产品预期一致
- [ ] 所有 `color-mix()` 都有前一行 fallback
- [ ] Tier B 下 flex `gap` / `aspect-ratio` / `inset` / `:focus-visible` 已降级或加 `@supports`
- [ ] Tier C 下换肤走方案 1 或 2，并有 `CSS.supports('--a','0')` 检测分支
- [ ] 构建产物区分现代包与 legacy 包（`nomodule`）
- [ ] 至少用 Playwright 在两个引擎上跑过视觉快照
- [ ] 框架 / 组件库自身的基线不低于目标浏览器
