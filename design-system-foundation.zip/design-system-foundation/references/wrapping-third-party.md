# 基于第三方组件库二次开发：门面 + 桥接

适用场景：老板说"基于 Element UI / Ant Design 二次开发，只用它的组件能力，其他不用"。

## 总体策略

```
业务代码  ──只认──>  Ds* 门面组件（自有 API 契约，永不改）
                        │
                        └──转调──>  el-* / a-*（内部实现细节，可随时换）
```

- **门面层**：对外暴露 `DsButton` `DsTable` …，props / 事件 / 插槽语义自己定，业务零改动
- **引入层**：集中注册第三方组件，业务侧**不许**直接 import 第三方
- **桥接层**：把第三方的硬编码色值反向接到我们的 Token 上

换底层组件库时，只动引入层与桥接层，`Ds*` 与业务代码不动。

## 一、引入层

集中一个文件，业务侧不直接 import 第三方：

```js
// src/element/index.js
/**
 * element-ui/lib/* 是 webpack 打包产物，导出形如 { default: Component }。
 * Rollup / Vite 的 CJS interop 在没有 __esModule 标记时，
 * 会把整个 module.exports 当作默认导出 —— 必须解包。
 */
const interop = (mod) => (mod && mod.default) || mod

const REGISTRY = {
  Button: interop(require('element-ui/lib/button')),
  Input:  interop(require('element-ui/lib/input')),
  // ...
}

export function installElement(VueCtor = Vue, options = {}) {
  const { size = 'small', zIndex = 3000 } = options
  VueCtor.prototype.$ELEMENT = { size, zIndex }
  ElementLocale.use(zhCN)
  Object.keys(REGISTRY).forEach((key) => {
    const comp = REGISTRY[key]
    if (comp && comp.name) VueCtor.component(comp.name, comp)  // 用自带 name，不要拼 'El' + key
  })
}
```

**坑 1：CJS interop。** 不解包会报 `Failed to mount component: template or render function not defined`，而且报错信息完全指不到根因。

**坑 2：注册名用组件自带的 `name`**（`ElButton`），不要用 `'El' + key` 拼——有些组件的 name 不符合这个规律。

**坑 3：构建配置。** element-ui 只发布 CJS（`lib/`），必须交给 esbuild 预构建：

```js
// vite.config.js
optimizeDeps: { include: ['element-ui', 'element-ui/lib/utils/vue-popper', /* ... */] }
```

## 二、桥接层：CSS 三层顺序

第三方主题是**编译期烧死色值**的 CSS（`#409EFF` 之类）。不要 fork 它的源码，用**同优先级、后加载**的方式反向接管：

```js
// main.js —— 顺序不能错
import './styles/base.css'            // 1) 第三方基础样式（按需引入时随组件自带）
import './styles/utilities.css'       // 2) 自有重置与工具类
import './styles/element-bridge.css'  // 3) Token 桥接层，必须最后
```

桥接层的写法——用**同优先级选择器**把色值换成变量：

```css
.el-button--primary {
  background: var(--ds-color-brand);
  border-color: var(--ds-color-brand);
  color: var(--ds-color-fg-on-brand);
}
.el-pager li.active {
  background: var(--ds-color-brand);
  color: var(--ds-color-fg-on-brand);
}
.v-modal { background: var(--ds-color-overlay); }
```

**坑 4：SVG 表现属性优先级最低。** 环形进度条的颜色 Element 是写在 `stroke` 属性上的，CSS 能直接覆盖：

```css
.el-progress-circle__path { stroke: var(--ds-color-brand); }
```

**坑 5：长度单位 / 圆角也要桥接**，不然换主题只能换色、换不了圆角。把 `--ds-radius-*` 套到 `.el-button` `.el-input__inner` `.el-card` 上。

## 三、封装契约

**坑 6：忽略第三方的内部载荷，按自己的 model 重算。**

Element 的 checkbox 回调会传布尔值，但我们的 model 可能是数组 / trueValue / falseValue 三态。直接透传会污染对外 API：

```js
// DsCheckbox.vue
checked() {
  if (Array.isArray(this.modelValue)) return this.modelValue.indexOf(this.value) > -1
  return this.modelValue === this.trueValue
},
onChange() {
  if (this.disabled) return
  if (Array.isArray(this.modelValue)) {
    const next = this.checked
      ? this.modelValue.filter((v) => v !== this.value)
      : this.modelValue.concat([this.value])
    this.$emit('change', next)
  } else {
    this.$emit('change', this.checked ? this.falseValue : this.trueValue)
  }
}
```

**坑 7：`$attrs` 透传行为不一致。** Vue 2 下 `el-input` 设了 `inheritAttrs: false` 且内部 `v-bind="$attrs"`（会落到真实 input），而 `el-select` / `el-button` / `el-table` / `el-checkbox` **不透传**。需要 aria 属性时得手动补：

```js
mounted() { this.syncAria() },
updated() { this.syncAria() },
syncAria() {
  const el = this.$el && this.$el.querySelector('input')
  if (!el) return
  if (this.error) el.setAttribute('aria-invalid', 'true')
  else el.removeAttribute('aria-invalid')
}
```

**坑 8：第三方的 props 校验器不接受空串。** 想"回落默认值"要传 `undefined`，不是 `''`：

```js
// 反例：el-progress 的 status 校验器只接受 success/warning/exception
elStatus() { return { danger: 'exception' }[this.tone] || '' }        // 触发 Vue 告警
// 正解
elStatus() { return { danger: 'exception' }[this.tone] || undefined }
```

**坑 9：第三方没有的能力要自己补，别硬传 prop。** Element 2.15 的 `el-progress` 没有 `indeterminate`，传了是无效 prop。正确做法是加类名 + 自己写动画：

```css
.ds-progress--indeterminate ::v-deep .el-progress-bar__inner {
  width: 35% !important;
  animation: ds-progress-slide 1.2s var(--ds-motion-ease-in-out) infinite;
}
```

**坑 10：某些组件强制要求祖先。** `el-form-item` 的 `form` 计算属性会一路向上找 `componentName === 'ElForm'`，**2.15 版本没有兜底**，找不到就读 undefined 的 `$options` 直接抛错。解法是外层恒包一层 `el-form`：

```js
created() {
  const outer = this.findElForm()
  if (outer) {
    this.formModel = outer.model || {}     // 外层有表单就透传，不截断校验语义
    this.formRules = outer.rules || {}
  }
},
methods: {
  findElForm() {
    let p = this.$parent
    while (p) {
      if (p.$options && p.$options.componentName === 'ElForm') return p
      p = p.$parent
    }
    return null
  }
}
```

模板用 `label-position="top"` 让标签在控件上方，并加 `@submit.native.prevent` 防止回车提交。

## 四、响应式自己承担

不要用第三方自带的断点系统。用自己的 `useBreakpoint`，在组件里做形态切换：

```js
// DsTable：<768px 时从表格转成卡片列表
computed: {
  isMobile() { return bpState.current === 'xs' || bpState.current === 'sm' }
}
```

## 五、构建与测试配置

```js
// vite.config.js
build: {
  target: 'esnext',
  minify: 'esbuild',        // element-ui 是 CJS，需要预构建
  rollupOptions: { output: { manualChunks: {
    vue: ['vue', 'vue-router', 'vuex'],
    element: ['element-ui'],
  } } },
},
test: {
  server: { deps: { inline: [/element-ui/, /async-validator/, /throttle-debounce/] } },
}
```

分开 chunk 后才能看出第三方的真实体积占比。

## 六、冒烟测试

**坑 11：Vue 2 的 `warn` 走 `console.error`。** 只 spy `console.warn` 会漏掉全部 Vue 告警：

```js
const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
const warnSpy  = vi.spyOn(console, 'warn').mockImplementation(() => {})

const wrapper = mount(Page, { store, stubs: { 'router-link': true, 'router-view': true } })
await wrapper.vm.$nextTick()
await wrapper.vm.$nextTick()          // el-table 需要等 2 个 tick

expect(errorSpy.mock.calls.map((c) => String(c[0]))).toEqual([])
expect(warnSpy.mock.calls.map((c) => String(c[0]))).toEqual([])
```

**坑 12：`el-table` 的列是子组件 mounted 时才注册的**，表头与单元格要等 2 个 tick 才渲染。写测试时封装一个 `settle()`：

```js
const settle = async (vm) => { await vm.$nextTick(); await vm.$nextTick() }
```

**坑 13：jsdom 下 `trigger('change')` 不会真的切换 `checked`。** 得手动设：

```js
input.element.checked = true
await input.trigger('change')
```

**坑 14：集成测试要用真实 store。** 自己 new 一个空 Vuex store 会因缺模块报 `Cannot read properties of undefined`，直接 `import store from '@/store'` 并传进去。

**坑 15：vitest 里 `require()` 不走 Vite 的别名解析。** 动态加载页面组件要用顶部静态 `import`，再组成数组传给 `it.each`：

```js
// 反例：Cannot find module '@/views/TableDocs.vue'
it.each([['TableDocs', () => require('@/views/TableDocs.vue').default]])

// 正解
import TableDocs from '@/views/TableDocs.vue'
it.each([['TableDocs', TableDocs]])
```

## 七、改造后的自检

- [ ] 全局搜不到业务代码直接 `import 'element-ui'`
- [ ] 每个 `el-*` 组件在桥接层都有对应色值映射（换个主题走查一遍）
- [ ] 5 主题 × 若干强调色下，所有页面无 Vue 告警
- [ ] 第三方 chunk 体积单独可见
- [ ] 没有一个 `Ds*` 组件把第三方的内部数据（布尔载荷、status 枚举）直接 emit 出去
