# Token 架构：分层与命名

## 三层结构

```
scale   ── 与主题无关的基础尺度（全局唯一）
  space / radius / font / fontSize / fontWeight / lineHeight
  motion / z / size

color   ── 每个主题一份（主题数 × 1）
  bg* / fg* / border* / brand* / success* / warning* / danger* / info*
  overlay / focus / skeleton

shadow  ── 明暗两套（2 份，不是每主题一份）
  shadow-sm / md / lg / xl / shadow-focus
```

派生函数：

```js
createTheme({ label, mode, color, shadowColor })
// => scale + color + shadowColor + shadowPresets[mode]
```

**为什么 shadow 只有两套而不是每主题一套**：阴影只有"压在亮底上"和"压在暗底上"两种物理情形。深色主题下用亮色阴影会完全看不见，必须换成纯黑高透明度。

## 命名公式

```
--{prefix}-{category}-{role}{Modifier}
     ds       color     brand   Subtle
```

- `prefix` —— 团队 / 产品标识，全项目唯一（`ds` = Design System）
- `category` —— `color` / `space` / `radius` / `font-size` / `motion-duration` / `z` / `size` / `shadow`
- `role` —— 作用在哪个面上：`bg` `fg` `border` `brand` `success` `warning` `danger` `info` `overlay` `focus` `skeleton`
- `Modifier` —— 强度或状态，首字母大写，短横线连接（`bgSubtle` → `--ds-color-bg-subtle`）

源码里用驼峰（`bgSubtle`），注入时统一转成短横线。转换只需一行：

```js
const kebab = (str) => String(str).replace(/[A-Z]/g, (m) => '-' + m.toLowerCase())
```

## 角色表

| role | 含义 |
|---|---|
| `bg` | 背景面（含 Subtle / Elevated / Inset / Hover / Active / Disabled） |
| `fg` | 文字色（含 Muted / Subtle / Disabled / OnBrand） |
| `border` | 边框（含 Subtle / Strong） |
| `brand` | 品牌色，会被强调色覆盖 |
| `success` / `warning` / `danger` / `info` | 四类语义色 |
| `overlay` | 遮罩层 |
| `focus` | 焦点环 |
| `skeleton` | 骨架屏 |

## 修饰后缀表

| 后缀 | 含义 | 典型搭配 |
|---|---|---|
| `-Subtle` | 最弱一档（浅底 / 淡字 / 极淡边框） | `brandSubtle` `fgSubtle` `borderSubtle` |
| `-Muted` | 次要文字，比 Subtle 强 | `fgMuted` |
| `-Hover` / `-Active` / `-Disabled` | 交互三态 | `brandHover` `bgActive` `fgDisabled` |
| `-Elevated` | 浮起层（弹层、卡片） | `bgElevated` |
| `-Inset` | 内凹层（代码块、输入框底、进度条槽） | `bgInset` |
| `-Strong` | 比默认 border 更实 | `borderStrong` |
| `-Fg` | 该语义色上**可读的文字色** | `dangerFg` `brandFg` `successFg` |
| `-Border` | 该语义色的描边 | `brandBorder` |
| `-OnBrand` | 品牌实心底上的文字（通常是白，深色主题下可能是深色） | `fgOnBrand` |

记忆口诀：**Subtle 永远最弱，Strong 永远最强，中间是默认值；`-Fg` / `-OnBrand` 管的是"写在它上面的字"而不是"它自己"。**

## 强度阶梯

语义色固定三档，从强到弱：

```
brand          #4f46e5   实心填充，最抢眼
  ↓
brandBorder    #c7d2fe   描边，中等
  ↓
brandSubtle    #eef2ff   浅底，最弱
```

文字色固定四档，从强到弱：

```
fg           #0f172a   正文
fgMuted      #4a5768   次要文字
fgSubtle     #94a3b8   提示、辅助信息
fgDisabled   #b6c0cd   禁用，不可点
```

背景面不是阶梯而是**层级**，彼此平行：

```
bg           页面底
bgSubtle     比底稍灰的一层（分区、表头）
bgElevated   浮起层（卡片、弹层、下拉）
bgInset      内凹层（代码块、输入框、进度槽）
```

## 常见陷阱

**1. 用透明度手搓 Subtle**

不要在组件里写 `opacity: 0.12` 或 `rgba(var(--ds-color-brand), 0.12)`。后者在 `brand` 是 hex 时会解析失败——必须预先准备**通道变量**（见 `color-notation.md`）。前者会让内容和背景一起变淡。

**2. 浅色主题用 hex 存 Subtle**

```js
// 反例：两个主题行为不一致
light.brandSubtle = '#eef2ff'                    // 不透明，盖掉底纹
dark.brandSubtle  = 'rgba(99, 102, 241, 0.16)'   // 融合

// 正解：都用 rgba
light.brandSubtle = 'rgba(79, 70, 229, 0.08)'
dark.brandSubtle  = 'rgba(99, 102, 241, 0.16)'
```

**3. Token 改名**

组件、业务代码、文档三处都会引用。改名成本远高于加一个新 Token。语义变了就新增，旧的可标 deprecated 但不要删。

**4. 把语义色和状态色混为一谈**

`danger` 是"危险"这个语义，`is-error` 是组件状态。组件内部用状态，对外暴露语义。不要在 Token 层定义 `error`，统一叫 `danger`。
