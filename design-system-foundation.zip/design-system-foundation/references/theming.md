# 主题与强调色：正交、注入、防闪烁

## 正交矩阵

主题和强调色是**两个独立的轴**，不是枚举组合：

```
主题（换明暗底）        强调色（换品牌色）
─────────────────      ────────────────
light     晨光          indigo   靛蓝
dark      夜幕          cyan     青碧
midnight  深空          emerald  翡翠
sunrise   暖阳          amber    琥珀
violet    霓紫          rose     玫瑰
                        violet   紫罗兰
                        (空)     跟随主题
```

5 × 7 = 35 种外观，代码里只维护 5 + 6 份配置。

**关键**：强调色需要一个"空"选项，表示跟随主题自带的品牌色：

```js
export const DEFAULT_ACCENT = ''   // 空串 = 用主题自己的 brand
```

否则每个主题都得配一套强调色，组合又爆炸了。

## 令牌解析顺序

后覆盖前，**三层叠加**：

```
主题 tokens
  ↓ 被覆盖
强调色 tokens（如果有）
  ↓ 被覆盖
手动 overrides（setToken 写入）
```

```js
export function resolveTokens() {
  const theme = state.themes[state.name] || state.themes[DEFAULT_THEME]
  const base = flattenTokens(theme.tokens)

  const accent = state.accent && state.accents[state.accent]
  if (accent) Object.assign(base, flattenTokens({ color: accent.tokens }))

  Object.assign(base, flattenTokens(state.overrides))
  return base
}
```

用这个顺序，`setToken` 能覆盖任意单个令牌（"随意改"能力），`resetTokens` 一键还原。

## 注入到 `<html>`

```js
function apply() {
  const el = document.documentElement
  const vars = resolveCssVars()          // { '--ds-color-bg': '#ffffff', ... }

  Object.keys(vars).forEach((name) => {
    el.style.setProperty(name, vars[name])
  })

  el.setAttribute('data-ds-theme', state.name)
  el.setAttribute('data-ds-mode', theme.mode)
  el.style.colorScheme = theme.mode      // 让原生控件（滚动条、下拉）跟着变
}
```

为什么写 `<html>` 而不是 `:root` 样式表：写内联 style 可以**运行时改**，切主题不触发任何组件重新渲染，性能开销≈0。

## 首屏防闪烁

在 `<head>` 里同步执行一小段脚本，早于 CSS 应用：

```html
<script>
  (function () {
    try {
      var raw = localStorage.getItem('aurora-ds:theme')
      var saved = raw ? JSON.parse(raw) : null
      var name = (saved && saved.name) || 'light'
      var mode = THEME_MODES[name] || 'light'   // 构建时内联的映射表
      document.documentElement.setAttribute('data-ds-mode', mode)
      document.documentElement.style.colorScheme = mode
    } catch (e) {}
  })()
</script>
```

要点：

- **同步执行**，不能 `defer`，不能等 DOMContentLoaded
- 只设 `data-ds-mode` 和 `color-scheme`，不设完整变量（令牌由 JS 初始化时再写）
- 需要一份静态的 `themeModes` 映射（主题名 → light/dark），构建时内联

## 深浅两套阴影

```js
export const shadowPresets = {
  light: {
    'shadow-sm': '0 1px 2px 0 rgb(var(--ds-shadow-color) / 0.06)',
    'shadow-md': '0 4px 12px -2px rgb(var(--ds-shadow-color) / 0.10)',
    'shadow-focus': '0 0 0 3px rgb(var(--ds-shadow-color) / 0.12)',
  },
  dark: {
    'shadow-sm': '0 1px 2px 0 rgb(0 0 0 / 0.5)',
    'shadow-md': '0 4px 14px -2px rgb(0 0 0 / 0.6)',
    'shadow-focus': '0 0 0 3px rgb(255 255 255 / 0.10)',
  },
}
```

深色主题下阴影**必须换成纯黑高透明度**，且聚焦环要用白色半透明——用亮色阴影在暗底上完全看不见。

`--ds-shadow-color` 存的是裸通道（`15 23 42`），不是完整颜色，这样才能在 `rgb()` 里配任意 alpha。

## 持久化与跟随系统

```js
state = { name, accent, overrides, followSystem, systemMode }
localStorage: { name, accent, overrides, followSystem }
```

- 隐私模式下 `localStorage` 写入会抛异常，**必须 try/catch 吞掉**
- 跟随系统用 `matchMedia('(prefers-color-scheme: dark)')`，注意兼容 `addEventListener` 与老式 `addListener`
- 一旦手动切主题，`followSystem` 置 false

## 运行时注册

支持从后台下发 JSON 新增主题：

```js
export function registerTheme(name, definition) {
  Vue.set(state.themes, name, definition)   // Vue 2 必须用 Vue.set 才能响应
  apply()
}
```

Vue 2 下往响应式对象加新 key 必须用 `Vue.set`，直接赋值不触发更新。`unregisterTheme` 同理要用 `Vue.delete`。

## 导出能力

提供 `exportCssVariables()` 输出 `:root { --ds-xxx: ...; }` 文本，方便贴到不跑 JS 的外部项目，或交给设计师核对。
