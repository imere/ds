/**
 * 内置主题：每个主题只声明「颜色」，其余尺度由 createTheme 自动补齐。
 * 新增主题：createTheme({...}) 后加进 themes，或在运行时 themeManager.registerTheme() 注册。
 *
 * 色值写法规则（详见 references/color-notation.md）：
 *   · 实色（bg / fg / border / brand / swatch）        -> hex
 *   · 半透明叠层（hover / active / disabled / overlay） -> rgba() 固定通道
 *   · 深浅主题的 xxxSubtle                              -> rgba()，不要用浅 hex
 */
import { createTheme } from './tokens'

export const themes = {
  light: createTheme({
    label: '晨光 Light',
    mode: 'light',
    color: {
      bg: '#ffffff',
      bgSubtle: '#f7f9fc',
      bgElevated: '#ffffff',
      bgInset: '#f1f5f9',
      bgHover: 'rgba(15, 23, 42, 0.045)',
      bgActive: 'rgba(15, 23, 42, 0.085)',
      bgDisabled: 'rgba(15, 23, 42, 0.04)',

      fg: '#0f172a',
      fgMuted: '#4a5768',
      fgSubtle: '#94a3b8',
      fgDisabled: '#b6c0cd',
      fgOnBrand: '#ffffff',

      border: '#e3e8ef',
      borderStrong: '#cbd5e1',
      borderSubtle: '#eef2f7',

      brand: '#4f46e5',
      brandHover: '#4338ca',
      brandActive: '#3730a3',
      brandSubtle: 'rgba(79, 70, 229, 0.08)',
      brandBorder: 'rgba(79, 70, 229, 0.32)',
      brandFg: '#4338ca',

      success: '#16a34a',
      successSubtle: 'rgba(22, 163, 74, 0.10)',
      successFg: '#15803d',
      warning: '#d97706',
      warningSubtle: 'rgba(217, 119, 6, 0.10)',
      warningFg: '#b45309',
      danger: '#dc2626',
      dangerSubtle: 'rgba(220, 38, 38, 0.10)',
      dangerFg: '#b91c1c',
      info: '#0284c7',
      infoSubtle: 'rgba(2, 132, 199, 0.10)',
      infoFg: '#0369a1',

      overlay: 'rgba(15, 23, 42, 0.46)',
      focus: '#4f46e5',
      skeleton: 'rgba(15, 23, 42, 0.08)',
    },
    shadowColor: '15 23 42',
  }),

  dark: createTheme({
    label: '夜幕 Dark',
    mode: 'dark',
    color: {
      bg: '#0b0f17',
      bgSubtle: '#111827',
      bgElevated: '#161d29',
      bgInset: '#0e141d',
      bgHover: 'rgba(255, 255, 255, 0.065)',
      bgActive: 'rgba(255, 255, 255, 0.11)',
      bgDisabled: 'rgba(255, 255, 255, 0.04)',

      fg: '#e6edf6',
      fgMuted: '#9aa8bd',
      fgSubtle: '#6b7a91',
      fgDisabled: '#4b586b',
      fgOnBrand: '#ffffff',

      border: '#232c3b',
      borderStrong: '#33415a',
      borderSubtle: '#1a222e',

      brand: '#6366f1',
      brandHover: '#818cf8',
      brandActive: '#a5b4fc',
      brandSubtle: 'rgba(99, 102, 241, 0.16)',
      brandBorder: 'rgba(99, 102, 241, 0.42)',
      brandFg: '#a5b4fc',

      success: '#22c55e',
      successSubtle: 'rgba(34, 197, 94, 0.16)',
      successFg: '#4ade80',
      warning: '#f59e0b',
      warningSubtle: 'rgba(245, 158, 11, 0.16)',
      warningFg: '#fbbf24',
      danger: '#ef4444',
      dangerSubtle: 'rgba(239, 68, 68, 0.16)',
      dangerFg: '#f87171',
      info: '#38bdf8',
      infoSubtle: 'rgba(56, 189, 248, 0.16)',
      infoFg: '#7dd3fc',

      overlay: 'rgba(2, 6, 15, 0.68)',
      focus: '#818cf8',
      skeleton: 'rgba(255, 255, 255, 0.08)',
    },
    shadowColor: '0 0 0',
  }),
}

export const DEFAULT_THEME = 'light'

/** 主题名 -> 明暗模式。构建时内联进 index.html 的防闪烁脚本 */
export const themeModes = Object.keys(themes).reduce((acc, key) => {
  acc[key] = themes[key].mode
  return acc
}, {})
