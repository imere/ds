/**
 * 强调色（Accent）预设
 * -------------------------------------------------------------
 * 与主题正交：换主题是换明暗底，换强调色是换品牌色，两者自由组合。
 *
 * `rgb` 参数传的是裸通道（'79 70 229'），不是完整颜色 —— 因为 subtle / border
 * 必须带 alpha 才能同时成立在浅色与深色底上，而 rgba() 里塞不进 hex。
 *
 * `swatch` 是该强调色的「展示色」，只用于 UI 上的色卡圆点；
 * `tokens` 才是真正注入 CSS 变量的那一套。
 */
const brand = (main, hover, active, focus, rgb) => ({
  brand: main,
  brandHover: hover,
  brandActive: active,
  brandSubtle: `rgba(${rgb}, 0.12)`,
  brandBorder: `rgba(${rgb}, 0.32)`,
  brandFg: hover,
  focus: main,
})

export const accents = {
  indigo: {
    label: '靛蓝 Indigo',
    swatch: '#4f46e5',
    tokens: brand('#4f46e5', '#4338ca', '#3730a3', '#6366f1', '79 70 229'),
  },
  emerald: {
    label: '翡翠 Emerald',
    swatch: '#059669',
    tokens: brand('#059669', '#047857', '#065f46', '#10b981', '5 150 105'),
  },
  rose: {
    label: '玫瑰 Rose',
    swatch: '#e11d48',
    tokens: brand('#e11d48', '#be123c', '#9f1239', '#fb7185', '225 29 72'),
  },
}

/** 空字符串 = 跟随主题自带品牌色。切换器上的「跟随主题」选项本身没有色值，
 *  所以每个强调色必须单独存一个 swatch 供展示用。 */
export const DEFAULT_ACCENT = ''
