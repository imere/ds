# 骨架使用说明

Vue 2 + Vite 场景下的最小可运行骨架。复制整个 `skeleton/` 到 `src/design/`，按下面 4 步接起来。

## 1. 复制文件

```
src/design/tokens.js
src/design/themes.js
src/design/accents.js
src/design/themeManager.js
```

## 2. 入口初始化

```js
// src/main.js
import Vue from 'vue'
import themeManager from '@/design/themeManager'

import './styles/base.css'
import './styles/utilities.css'
// 若接入第三方组件库：import './styles/element-bridge.css'  ← 必须最后

themeManager.init()          // 早于 new Vue()
new Vue({ /* ... */ }).$mount('#app')
```

## 3. 首屏防闪烁

在 `index.html` 的 `<head>` 里同步执行（不要 defer）。把 `themeModes` 的映射内联进去：

```html
<script>
  (function () {
    var MODES = { light: 'light', dark: 'dark' }   // 构建时从 themeModes 内联
    try {
      var saved = JSON.parse(localStorage.getItem('my-ds:theme') || '{}')
      var name = saved.name || 'light'
      var mode = MODES[name] || 'light'
      var el = document.documentElement
      el.setAttribute('data-ds-mode', mode)
      el.style.colorScheme = mode
    } catch (e) {}
  })()
</script>
```

## 4. 组件里只消费变量

```css
.ds-card {
  background: var(--ds-color-bg-elevated);
  border: 1px solid var(--ds-color-border);
  border-radius: var(--ds-radius-lg);
  color: var(--ds-color-fg);
}
```

组件样式里出现 `#xxxxxx` 或硬编码 `rgb(` 都视为缺陷。

## 需要替换的占位

| 位置 | 占位 | 说明 |
|---|---|---|
| `themeManager.js` | `my-ds:theme` | localStorage key，改成产品标识 |
| `tokens.js` | `TOKEN_PREFIX = 'ds'` | CSS 变量前缀 |
| `themes.js` | 两套主题 | 至少需要 light + dark |
| `accents.js` | 三个强调色 | 至少保留一个 + 空串选项 |

## 验证

```bash
npx vitest run     # 主题切换后无 Vue 告警
npx vite build     # 构建通过
```

再手工走查：5 主题 × 若干强调色下，所有页面无告警、深色主题阴影仍可见、首屏切主题不闪白。
