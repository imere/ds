---
name: design-system-foundation
description: 从零搭建或重构一套 Design System 底层——Design Token 的分层与命名、明暗主题与强调色的正交组合、颜色值写法（hex / rgba / 通道变量 / color-mix）的选择规则、基于第三方组件库二次封装的门面与桥接模式、老浏览器兼容分级与工具链选型、以及页面级冒烟测试。当用户提到"建组件库""做设计系统""支持多主题""Design Token 切换""主题换肤""基于 Element UI / Ant Design / Mantine 等二次开发""只用人家的组件能力，主题和响应式自己控""要不要兼容 IE11 / 老浏览器""browserslist 怎么配"时使用。
agent_created: true
---

# Design System 底层方法论

## 何时使用

在以下任一情形加载本 skill：

- 从零搭一套组件库 / 设计系统
- 给现有系统加多主题、加 Design Token 运行时切换
- 基于某个第三方组件库做二次开发，且要求"只用它的组件能力，视觉与响应式自己控"
- 评审或重构一套已有的 Token 体系（命名混乱、色值硬编码、主题不可切）

## 心智模型

一句话：**把"不变的"和"会变的"分开，再让"会变的"之间彼此正交。**

| 层 | 是否随主题变 | 内容 |
|---|---|---|
| `scale` | 否 | 间距、圆角、字号、字重、行高、动效、层级、控件高度 |
| `color` | 是 | 每个主题一份完整色板 |
| `shadow` | 是 | 明暗两套，深色下阴影会"消失"，必须单独给 |

两个**独立**的变轴，可自由组合（5 主题 × 6 强调色 = 30 种外观）：

- **主题** = 换明暗底
- **强调色** = 换品牌色

组件样式**只消费 CSS 变量**，永不出现硬编码色值。改一个变量全站生效，无需重渲染。

## 工作流

0. **先定兼容 Tier** —— 这是架构级决策，不是补丁。CSS 自定义属性在 IE11 完全不可用，若必须支持 IE，整套"变量注入 `<html>`"方案要换成"多套静态 CSS + class 切换"。见 `references/compatibility.md`
1. **定前缀与命名公式** —— 一律 `--{prefix}-{category}-{role}{Modifier}`，见 `references/token-architecture.md`
2. **拆 Token 三层** —— scale / color / shadow，scale 全局共享，color 与 shadow 每主题一份
3. **建主题与强调色** —— 两者正交；强调色留一个空串常量表示"跟随主题自带色"
4. **注入 `<html>` + 防闪烁** —— 见 `references/theming.md`
5. **组件只消费变量** —— 任何组件样式里出现 `#` 或 `rgb(` 都视为缺陷
6. **（可选）第三方库二次封装** —— 门面 + 桥接，见 `references/wrapping-third-party.md`
7. **页面级冒烟** —— 挂载所有页面，断言 `console.error` 为空

## 硬规则

以下每条都是踩过坑后的约束，不要凭直觉绕开。

1. **Token 只增不改名。** 组件与业务都会引用变量名，改名等于全量破坏。需要新语义就加新 Token。
2. **`Subtle` 永远是最弱一档，`Strong` 永远是最强一档，中间是默认值。** 不要反过来用。
3. **`-Fg` / `-OnBrand` 指的是"写在它上面的字"，不是"它自己"。** `dangerFg` 是 danger 底色上可读的文字色。
4. **需要透出下面内容的颜色，一律带 alpha。** 判断问题只有一个："这颜色下面会露出什么？"答不出来就必须透明。
5. **深浅主题的 `xxxSubtle` 都必须用 rgba。** 浅色主题用预烘焙的浅 hex 会盖掉底纹，导致同一 Token 在两种主题下融合行为不一致。
6. **组件封装保留自己的 props / 事件契约。** 内部转调第三方时，忽略第三方的内部载荷，按自己的 model 重算，否则第三方的 `checked`、`status` 等语义会污染对外 API。
7. **第三方主题由桥接层反向接管，不 fork 它的源码。** 见 `references/wrapping-third-party.md` 的 CSS 三层顺序。
8. **响应式 / 断点由自己承担。** 第三方库自带断点不纳入体系，移动端形态（如表格转卡片）自己实现。
9. **Vue 2 的 `warn` 走 `console.error`。** 冒烟测试只 spy `console.warn` 会漏掉全部 Vue 告警。
10. **兼容性先定 Tier 再动手。** Tier A（evergreen）只需给 `color-mix()` 留 fallback；Tier B（iOS 13 / Safari 13）要避开 flex `gap`、`inset`、`aspect-ratio`、`:focus-visible`；Tier C（IE11）CSS 变量地基失效，换肤必须整体降级。不要在没有明确目标时就开始写。
11. **`var()` 的第二个参数就是 fallback。** Tier C 下每个变量用法都要写 `var(--ds-color-fg, #0f172a)`；Tier A/B 不要为此污染代码。
12. **jsdom 测不出兼容问题。** 它不渲染 CSS 也不实现 `CSS.supports`，验证必须落 Playwright 真实引擎。

## 资源索引

按需加载，不要一次全读：

- `references/token-architecture.md` —— 三层结构、命名公式、角色表、修饰后缀表、强度阶梯
- `references/color-notation.md` —— hex / rgba / 通道变量 / color-mix 的选择规则与理由
- `references/theming.md` —— 正交矩阵、CSS 变量注入、首屏防闪烁、深浅阴影、Token 覆盖机制
- `references/wrapping-third-party.md` —— 门面 + 桥接模式、CJS interop、$attrs 透传差异、异步列注册等坑
- `references/compatibility.md` —— 兼容 Tier 分级、风险清单、browserslist / babel / core-js / autoprefixer / @vitejs/plugin-legacy / css-vars-ponyfill 选型
- `assets/skeleton/` —— 可直接复制改的 Vue 2 骨架：`tokens.js` / `themes.js` / `accents.js` / `themeManager.js`

## 落地检查清单

交付前逐条自查：

- [ ] 组件样式里搜不到 `#xxxxxx` 与硬编码 `rgb(`
- [ ] 每个主题都能独立渲染全部组件（不只是换主色）
- [ ] 强调色切换后，subtle / border / fg 三档都跟着变
- [ ] 深色主题下阴影仍然可见
- [ ] 首屏切换主题不闪白
- [ ] 页面级冒烟 `console.error` 为空
- [ ] 第三方组件的所有可见色都在桥接层里有映射
- [ ] `browserslist` 写死了明确目标，`npx browserslist` 输出符合预期
- [ ] 所有 `color-mix()` 有前一行 fallback
- [ ] Tier B/C 下 flex `gap` / `aspect-ratio` / `inset` / `:focus-visible` 已处理
- [ ] Tier C 下换肤降级方案已落地并有 `CSS.supports('--a','0')` 分支
- [ ] 用 Playwright 在至少两个引擎上跑过视觉快照
